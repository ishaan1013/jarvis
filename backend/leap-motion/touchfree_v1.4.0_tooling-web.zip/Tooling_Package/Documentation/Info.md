Documentation will be generated here.

This file is here to ensure the folder exists despite its contents being gitignored